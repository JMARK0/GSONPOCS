package com.bcbsma.poc.gson;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;

public class GSONUtility {

	private static Object JSONObj = null;
	private static Gson gson = null;
	private static String JSONString = null;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	// generic Method to De- serilize the JSON into Object
	public static Object deserialzeJson(MbElement JSONMessage,
			Class MessageClass) throws MbException {

		byte[] jsonBytes = JSONMessage.getLastChild().toBitstream(null, null,
				null, 0, 0, 0);
		String payload = new String(jsonBytes);

		gson = new GsonBuilder().setPrettyPrinting().create();
		JSONObj = gson.fromJson(payload, MessageClass);

		return JSONObj;
	}

	// Generic method to serilize the object into JSON message format
	public static byte[] serialzeJson(Object MessageClass) throws MbException {

		if (null != MessageClass)
			JSONString = gson.toJson(MessageClass);

		byte[] responseBytes = JSONString.getBytes();

		return responseBytes;
	}

}
