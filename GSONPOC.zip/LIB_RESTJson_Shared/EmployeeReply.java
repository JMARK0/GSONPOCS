package com.rapi.bcbsma.member.memberrights.bean;
/**
* 
 * @author jmarka01
*
*/
public class EmployeeReply {
	
	private String Id;
	private String  Name;
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EmployeeReply [Id=");
		builder.append(Id);
		builder.append(", Name=");
		builder.append(Name);
		builder.append("]");
		return builder.toString();
	}
	
	
	
	

}
