package com.rapi.bcbsma.member.memberrights.bean;
/**
* 
 * @author jmarka01
*
*/
 public class Employee {
	
	private String employeeId;
	private String  employeeName;
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Employee [employeeId=");
		builder.append(employeeId);
		builder.append(", employeeName=");
		builder.append(employeeName);
		builder.append("]");
		return builder.toString();
	}
	
	
	
	
}
